## v4.9.37 Changes

* [Classic] TOC bump for 1.13.5

[Known Issues](http://support.tradeskillmaster.com/display/KB/TSM4+Currently+Known+Issues)
